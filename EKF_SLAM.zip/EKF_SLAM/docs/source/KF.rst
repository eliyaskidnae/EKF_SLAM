Kalman Filter
=============

.. figure:: ../../pyreverse_output/KF.png
   :scale: 75 %
   :align: center
   :alt: Kalman Filter Class Diagram

.. autoclass:: KF.KF


