4 DOF AUV Dead REckoning using DVL and Gyro
===========================================
.. figure:: ../../pyreverse_output/DR_4DOFAUV_DVLGyro.png
   :scale: 75 %
   :align: center
   :alt: DR_4DOFAUV_DVLGyro Class Diagram

.. autoclass:: DR_4DOFAUV_DVLGyro.DR_4DOFAUV_DVLGyro

3 DOF Differential Drive Mobile Robot Example
=============================================
.. figure:: ../../pyreverse_output/DR_3DOFDifferentialDrive.png
   :scale: 75 %
   :align: center
   :alt: DR_3DOFDifferentialDrive Class Diagram

.. autoclass:: DR_3DOFDifferentialDrive.DR_3DOFDifferentialDrive
