Gaussian Filter
===============
.. figure:: ../../pyreverse_output/GaussianFilter.png
   :scale: 75 %
   :align: center
   :alt: Gaussian Filter Class Diagram

.. autoclass:: GaussianFilter.GaussianFilter

