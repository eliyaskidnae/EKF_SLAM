Extended Kalman  Filter
=======================

.. figure:: ../../pyreverse_output/EKF.png
   :scale: 75 %
   :align: center
   :alt: Extended Kalman Filter Class Diagram

.. autoclass:: EKF.EKF